/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Allow Cloudflare tunnels to connect to Next.js dev server without being blocked
  allowedDevOrigins: [
    'starter-jefferson-alert-pressure.trycloudflare.com',
    'integrated-tracy-demo-rendered.trycloudflare.com',
  ],
  async rewrites() {
    return [
      {
        source: '/uploads/:path*',
        destination: 'http://localhost:5000/uploads/:path*' // Connects to your local Node.js backend
      },
      {
        source: '/api/:path*',
        destination: 'http://localhost:5000/api/:path*' // Connects to your local Node.js backend
      }
    ]
  }
};

export default nextConfig;
